﻿<?php
// language file

// Global Text
define('POWEREDBY','Powered By:');
define('VERSION','Ver.');
define('PUBLISH','öffentlich');
define('UNPUBLISH','unveröffentlicht');
define('ACTIVE','Aktiv');
define('CREATEDON','Erstellt am');
define('ACTIONS','Bearbeiten');
define('SEARCH','Suchen');
define('GO','Los');
define('SAVE','Speichern');
define('UPDATE','aktualisieren');
define('RESET','zurücksetzen');
define('HEADSUP','Achtung!');
define('WELLDONE','Erfolgreich durchgeführt!');
define('SORRY','Entschuldigung !');
define('ONE_RECORD_UPDATED','Einen Eintrag aktualisiert.');
define('ONE_RECORD_SAVED','Einen eintrag gesichert.');
define('INVALID_IMAGE_FORMAT','Falsches Bildformat');

// Index Page text
define('PLEASE_SIGN_IN','Bitte anmelden');
define('LOGIN_USERNAME','Benutzername');
define('LOGIN_PASSWORD','Passwort');
define('LOGIN_INVALID','Ungültige Zugangsdaten.');
define('LOGIN_USERNAME_PLACEHOLDER','Bitte einen Benutzernamen angeben!');
define('LOGIN_PASSWORD_PLACEHOLDER','Bitte das Passwort angeben!');
define('LOGIN_SIGNIN','Log In');



// NAVIGATIONS
define('LOGOUT','<i class="fa fa-sign-out fa-fw"></i> Abmelden');

define('UTILITY','<i class="fa fa-wrench fa-fw"></i> Dienstprogramm<span class="fa arrow"></span>');
define('PHP_INFO','PHP Info');
define('SYSTEM_INFO','System Info');
define('IP_BLACKLIST_CHECKER','IP Blacklist Prüfung');

define('MANAGE_MAIL','<i class="fa fa-envelope fa-fw"></i> Mail Verwaltung<span class="fa arrow"></span>');
define('MAILBOXES','Postfächer');
define('WEBMAIL','Web Mail');

define('MANAGE_DATABASE','<i class="fa fa-database fa-fw"></i> Datenbank Verwaltung<span class="fa arrow"></span>');
define('MYSQL_DATABASE','MySql Datenbank');
define('MYSQL_USERS','MySql Benutzer');
define('PHPMYADMIN','PhpMyAdmin');

define('MANAGE_FILE','<i class="fa fa-sitemap fa-fw"></i> Datei Verwaltung<span class="fa arrow"></span>');
define('FTP_USERS','FTP Benutzer');
define('FILE_MANAGER','Datei Verwaltung');

define('SETTINGS','<i class="fa fa-gears fa-fw"></i> Einstellungen<span class="fa arrow"></span>');
define('CHANGE_PASSWORD','Passwort ändern');
define('EDIT_SETTINGS','Einstellungen ändern');


// Manage Mailbox
define('MANAGE_MAILBOXES','Postfächer Verwaltens');
define('MAILBOX_NAME','Email ID');
define('ADD_NEW_MAILBOX','Neues Postfach anlegen');
define('CHANGE_PASSWORD_MAILBOX','Passwort ändern');
define('MAILBOX_PLACEHOLDER','Bitte eine eMail angeben');
define('MAILBOX_PASSWORD','Passwort');
define('MAILBOX_DOMAIN_NAME','Domain');
define('MAILBOX_EXIST','Postfach schon vorhanden.');
define('MAIL_BOX_SETTINGS','Postfach Einstellungen :');
define('EMAIL_USERNAME','Benutzername');
define('INCOMING_SERVER','Eingangsserver');
define('OUTGOING_SERVER','Ausgangsserver');
define('AUTH_MESSAGE','Für IMAP, POP3 und SMTP-Authentifizierung erforderlich.');


// Manage FTP Users
define('MANAGE_FTP_USERS','Verwalte FTP Zugänge');
define('ADD_NEW_FTP_USER','Neuen FTP Benutzer');
define('FTP_USER','FTP Benutzer');
define('HOME_DIRECTORY','Start Verzeichniss');
define('FTP_HOST','FTP Host');
define('EDIT_FTP_USER','Bearbeite FTP Benutzerr');
define('FTP_USER_PLACEHOLDER','Bitte FTP Benutzer eintragen');
define('HOME_DIRECTORY_PLACEHOLDER','Bitte das STartverzeichniss wählen');
define('FTP_USER_EXIST','FTP Benutzer besteht schon.');
define('FTP_HOME_DIR_START','Bitte mit / beginnen');


// Mysql DB
define('MANAGE_MYSQLDB','Verwalte Mysql DB');
define('ADD_NEW_DB','Neue Datenbank anlegen');
define('DB_NAME','Datenbank Name');
define('DB_NAME_PLACEHOLDER','Bitte einen Datenbank Namen');
define('MYSQL_DB_EXIST','MsqlDB schon vorhanden.');

// Mysql User
define('MANAGE_MYSQL_USERS','Verwalte Mysql Benutzer');
define('ADD_MYSQL_USER','Neuen Mysql Benutzer anlegen');
define('MYSQL_USER_NAME','Datenbank Benutzer');
define('MYSQL_USER_NAME_PLACEHOLDER','Bitte Benutzernamen angeben');
define('MYSQL_PASSWORD_PLACEHOLDER','Bitte ein Passwort eingeben');

define('MYSQL_MYSQL_PASSWORD','Passwort');
define('MYSQL_DB_NAME','DB Name');

// IP checker
define('IP_CHECKER_MESSAGE','Die Server IP ist nicht auf der Blackliste von : ');

// Change Password
define('PANEL_USERNAME','Benutzername');
define('PANEL_USERNAME_PLACEHOLDER','Bitte Benutzernamen angeben');
define('PANEL_OLD_PASSWORD','altes Passwort');
define('PANEL_OLD_PASSWORD_PLACEHOLDER','Bitte altes Passwort angeben');
define('PANEL_NEW_PASSWORD','neues Passwort');
define('PANEL_NEW_PASSWORD_PLACEHOLDER','Bitte neues Passwort angeben');
define('INVALID_OLD_PASSWORD','ungültiges altes Passwort');

// Dashboard
define('TOTAL_MAILBOXES','Anzahl vorhandener Postfächer');
define('TOTAL_DATABASE','Anzahl vorhandener Datenbanken');
define('TOTAL_FTP_ACCOUNTS','Anzahl vorhandener FTP Zugänge');